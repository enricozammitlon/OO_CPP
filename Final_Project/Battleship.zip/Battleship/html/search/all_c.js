var searchData=
[
  ['name',['name',['../classbattle__ship_1_1vessel.html#a7c7d199acda1b8914c1b014d7d2893b3',1,'battle_ship::vessel']]],
  ['notification_5fmanager',['notification_manager',['../classbattle__ship_1_1notification__manager.html',1,'battle_ship::notification_manager'],['../classbattle__ship_1_1notification__manager.html#a87ccb2f8410219be087e216ae0dd0512',1,'battle_ship::notification_manager::notification_manager()']]],
  ['notification_5fmanager_2ecpp',['notification_manager.cpp',['../notification__manager_8cpp.html',1,'']]],
  ['notification_5fmanager_2eh',['notification_manager.h',['../notification__manager_8h.html',1,'']]],
  ['npc',['npc',['../classbattle__ship_1_1npc.html',1,'battle_ship::npc'],['../classbattle__ship_1_1npc.html#ab92a83aba6dbf1060ebdb666087790b8',1,'battle_ship::npc::npc()=default'],['../classbattle__ship_1_1npc.html#a6a5c77aa108694177865edb9c2d06947',1,'battle_ship::npc::npc(std::string uname, size_t diff)']]],
  ['npc_2ecpp',['npc.cpp',['../npc_8cpp.html',1,'']]],
  ['npc_2eh',['npc.h',['../npc_8h.html',1,'']]]
];
