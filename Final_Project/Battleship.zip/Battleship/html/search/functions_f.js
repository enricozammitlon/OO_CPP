var searchData=
[
  ['vessel',['vessel',['../classbattle__ship_1_1vessel.html#a6f3be9c2343940c262fb7add97402311',1,'battle_ship::vessel::vessel()=default'],['../classbattle__ship_1_1vessel.html#ade7f1d4ee4b458a715a0259e5211db20',1,'battle_ship::vessel::vessel(std::string n, coordinates p, size_t l, size_t w, std::string xy_rep_hor, std::string xy_rep_ver, orientation o, size_t ap)']]]
];
