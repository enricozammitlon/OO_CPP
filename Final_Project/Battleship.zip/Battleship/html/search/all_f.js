var searchData=
[
  ['raft',['raft',['../classbattle__ship_1_1raft.html',1,'battle_ship::raft'],['../classbattle__ship_1_1raft.html#acde3f010cdf8cb639c6c9996c4a31656',1,'battle_ship::raft::raft()=default'],['../classbattle__ship_1_1raft.html#ab76a787da1c470907eb7e166af6e0db8',1,'battle_ship::raft::raft(coordinates p, orientation o)']]],
  ['raft_2eh',['raft.h',['../raft_8h.html',1,'']]],
  ['ready_5fto_5fplay',['ready_to_play',['../classbattle__ship_1_1player.html#a48a3f8c692c7ea1def384c39b9b65e85',1,'battle_ship::player']]],
  ['remove_5fpiece',['remove_piece',['../classbattle__ship_1_1board.html#a19d236125f444778e5789109d9c1093b',1,'battle_ship::board::remove_piece()'],['../classbattle__ship_1_1human.html#a2638497165f4a593b3b597a785fc3ee0',1,'battle_ship::human::remove_piece()']]],
  ['reset',['reset',['../classbattle__ship_1_1player.html#ae21fefa953f6a3a0476cabfae7084bbf',1,'battle_ship::player']]],
  ['reset_5fnotifiations',['reset_notifiations',['../classbattle__ship_1_1notification__manager.html#ad5b73a016f63f919695dd8387c895d50',1,'battle_ship::notification_manager']]],
  ['row',['row',['../structbattle__ship_1_1coordinates.html#a68c97ae4b9f30e2d5f20f3727546a29b',1,'battle_ship::coordinates']]]
];
