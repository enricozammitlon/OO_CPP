var searchData=
[
  ['take_5fhit',['take_hit',['../classbattle__ship_1_1piece.html#a77642906503e12eb22fcfbc3eab98cb5',1,'battle_ship::piece::take_hit()'],['../classbattle__ship_1_1vessel.html#ab0da3c305902d55594b7aa5d20b69509',1,'battle_ship::vessel::take_hit()']]],
  ['toggle_5fturn',['toggle_turn',['../classbattle__ship_1_1game.html#a0e5a85f6c1f0cff5e1104545b5222026',1,'battle_ship::game']]]
];
