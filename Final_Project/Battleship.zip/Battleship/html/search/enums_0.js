var searchData=
[
  ['orientation',['orientation',['../namespacebattle__ship.html#aed87488f0a73f0d0679fe343fb61c784',1,'battle_ship']]]
];
