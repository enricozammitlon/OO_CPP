var searchData=
[
  ['operator_3c_3c',['operator&lt;&lt;',['../classbattle__ship_1_1board.html#a1a31fc970cf43cac6d5b1a44e3831f5d',1,'battle_ship::board::operator&lt;&lt;()'],['../structbattle__ship_1_1coordinates.html#a3addd697b39df26c1807d744c30e65b5',1,'battle_ship::coordinates::operator&lt;&lt;()'],['../classbattle__ship_1_1notification__manager.html#ae88cf18d6c7447486803aa949db9b667',1,'battle_ship::notification_manager::operator&lt;&lt;()']]],
  ['operator_3e_3e',['operator&gt;&gt;',['../structbattle__ship_1_1coordinates.html#afd9a944ba3ab08355a0ae36d35e57d85',1,'battle_ship::coordinates']]]
];
