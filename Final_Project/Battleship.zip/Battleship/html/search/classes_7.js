var searchData=
[
  ['notification_5fmanager',['notification_manager',['../classbattle__ship_1_1notification__manager.html',1,'battle_ship']]],
  ['npc',['npc',['../classbattle__ship_1_1npc.html',1,'battle_ship']]]
];
