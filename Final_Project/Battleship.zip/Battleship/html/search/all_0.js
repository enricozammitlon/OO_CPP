var searchData=
[
  ['a',['A',['../namespacebattle__ship.html#ab3bfa90e413692dac2d4463364f80561a7fc56270e7a70fa81a5935b72eacbe29',1,'battle_ship']]],
  ['action_5fpoints',['action_points',['../classbattle__ship_1_1vessel.html#a5d2b710e2b58847818ba8e22794a97a4',1,'battle_ship::vessel']]],
  ['add_5fhighscore',['add_highscore',['../classbattle__ship_1_1highscore__manager.html#ad53b09dec3b84ab8cc9ccf607ea1ffd8',1,'battle_ship::highscore_manager']]],
  ['add_5fnotification',['add_notification',['../classbattle__ship_1_1notification__manager.html#abb17bb5ac063b9ba4e7d0aa8a15e3628',1,'battle_ship::notification_manager']]],
  ['add_5fpiece',['add_piece',['../classbattle__ship_1_1human.html#adaea883b2eb5fa5932a9d7239c90bfd6',1,'battle_ship::human']]],
  ['all_5fhighscores',['all_highscores',['../classbattle__ship_1_1highscore__manager.html#a3a51d2dfb6210fea016ef59238d35861',1,'battle_ship::highscore_manager']]],
  ['all_5fpieces',['all_pieces',['../classbattle__ship_1_1market__manager.html#aa3d94799ba18b9a14edc9b2edc0ffd8d',1,'battle_ship::market_manager']]],
  ['already_5ftargeted',['already_targeted',['../classbattle__ship_1_1player.html#ac0905b76a660cd06e5fd45f4960d48f9',1,'battle_ship::player']]],
  ['assign_5fenemy',['assign_enemy',['../classbattle__ship_1_1player.html#a3525c2934ea6a4bd7600385cb5fa6bfa',1,'battle_ship::player']]],
  ['attack',['attack',['../classbattle__ship_1_1human.html#ad89701f0c4dd688c564b14a015059386',1,'battle_ship::human::attack()'],['../classbattle__ship_1_1npc.html#abe6ec844c73c5410c2c4887fd50fac06',1,'battle_ship::npc::attack()'],['../classbattle__ship_1_1player.html#a86be2256620cd5e20da6db7be8afdbc8',1,'battle_ship::player::attack()']]],
  ['authentication',['authentication',['../classbattle__ship_1_1authentication.html',1,'battle_ship']]],
  ['authentication_2ecpp',['authentication.cpp',['../authentication_8cpp.html',1,'']]],
  ['authentication_2eh',['authentication.h',['../authentication_8h.html',1,'']]]
];
