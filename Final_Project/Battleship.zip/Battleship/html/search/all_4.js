var searchData=
[
  ['e',['E',['../namespacebattle__ship.html#ab3bfa90e413692dac2d4463364f80561a3a3ea00cfc35332cedf6e5e9a32e94da',1,'battle_ship']]],
  ['edit_5fpiece',['edit_piece',['../classbattle__ship_1_1board.html#ab6dad94144c5142f3b956a78c6810a24',1,'battle_ship::board::edit_piece()'],['../classbattle__ship_1_1human.html#a8f0addc975b597a92d4c82849c2fff5d',1,'battle_ship::human::edit_piece()']]],
  ['end_5fcoordinates',['end_coordinates',['../classbattle__ship_1_1vessel.html#a90baf292572ee968095c107ec656db32',1,'battle_ship::vessel']]],
  ['enemy',['enemy',['../classbattle__ship_1_1player.html#af01292346caaf209039b6490ae18d8aa',1,'battle_ship::player']]]
];
