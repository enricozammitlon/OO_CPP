var searchData=
[
  ['has_5fplayer_5flost',['has_player_lost',['../classbattle__ship_1_1game.html#a2f6eceb02db97507f52e08c1dafcf5e4',1,'battle_ship::game']]],
  ['has_5fsunk',['has_sunk',['../classbattle__ship_1_1piece.html#af22bd781f4206decd0beed89b014d1cc',1,'battle_ship::piece::has_sunk()'],['../classbattle__ship_1_1vessel.html#a5f36d687fbb87ced436d2d88847a1d5c',1,'battle_ship::vessel::has_sunk()']]],
  ['human',['human',['../classbattle__ship_1_1human.html#abf9adbf70e2b5cec288c900f337f4c56',1,'battle_ship::human::human()=default'],['../classbattle__ship_1_1human.html#a9d8abd36c22aeddad8c57a5b1e74b4cd',1,'battle_ship::human::human(std::string uname, size_t high, size_t pass=0)']]]
];
