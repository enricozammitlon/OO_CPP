var searchData=
[
  ['add_5fhighscore',['add_highscore',['../classbattle__ship_1_1highscore__manager.html#ad53b09dec3b84ab8cc9ccf607ea1ffd8',1,'battle_ship::highscore_manager']]],
  ['add_5fnotification',['add_notification',['../classbattle__ship_1_1notification__manager.html#abb17bb5ac063b9ba4e7d0aa8a15e3628',1,'battle_ship::notification_manager']]],
  ['add_5fpiece',['add_piece',['../classbattle__ship_1_1human.html#adaea883b2eb5fa5932a9d7239c90bfd6',1,'battle_ship::human']]],
  ['assign_5fenemy',['assign_enemy',['../classbattle__ship_1_1player.html#a3525c2934ea6a4bd7600385cb5fa6bfa',1,'battle_ship::player']]],
  ['attack',['attack',['../classbattle__ship_1_1human.html#ad89701f0c4dd688c564b14a015059386',1,'battle_ship::human::attack()'],['../classbattle__ship_1_1npc.html#abe6ec844c73c5410c2c4887fd50fac06',1,'battle_ship::npc::attack()'],['../classbattle__ship_1_1player.html#a86be2256620cd5e20da6db7be8afdbc8',1,'battle_ship::player::attack()']]]
];
