var searchData=
[
  ['market_5fmanager',['market_manager',['../classbattle__ship_1_1market__manager.html',1,'battle_ship']]]
];
