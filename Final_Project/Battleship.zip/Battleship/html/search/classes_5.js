var searchData=
[
  ['highscore_5fmanager',['highscore_manager',['../classbattle__ship_1_1highscore__manager.html',1,'battle_ship']]],
  ['human',['human',['../classbattle__ship_1_1human.html',1,'battle_ship']]]
];
