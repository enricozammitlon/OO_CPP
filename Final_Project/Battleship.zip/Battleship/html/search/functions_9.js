var searchData=
[
  ['notification_5fmanager',['notification_manager',['../classbattle__ship_1_1notification__manager.html#a87ccb2f8410219be087e216ae0dd0512',1,'battle_ship::notification_manager']]],
  ['npc',['npc',['../classbattle__ship_1_1npc.html#ab92a83aba6dbf1060ebdb666087790b8',1,'battle_ship::npc::npc()=default'],['../classbattle__ship_1_1npc.html#a6a5c77aa108694177865edb9c2d06947',1,'battle_ship::npc::npc(std::string uname, size_t diff)']]]
];
