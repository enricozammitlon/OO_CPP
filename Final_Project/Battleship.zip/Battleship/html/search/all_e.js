var searchData=
[
  ['piece',['piece',['../classbattle__ship_1_1piece.html',1,'battle_ship']]],
  ['piece_2eh',['piece.h',['../piece_8h.html',1,'']]],
  ['play',['play',['../classbattle__ship_1_1game.html#a8bd311ac1aaab0a16c06b4f1b9664af4',1,'battle_ship::game']]],
  ['player',['player',['../classbattle__ship_1_1player.html',1,'battle_ship::player'],['../classbattle__ship_1_1player.html#a54df3c03653a24049b9629ce5c55fafa',1,'battle_ship::player::player()=default'],['../classbattle__ship_1_1player.html#a9c5da318ece63c6bdd3825cfa6ea9b4f',1,'battle_ship::player::player(std::string uname, bool ready, std::string sub)']]],
  ['player_2ecpp',['player.cpp',['../player_8cpp.html',1,'']]],
  ['player_2eh',['player.h',['../player_8h.html',1,'']]],
  ['player_5fboard',['player_board',['../classbattle__ship_1_1player.html#a7a463dddbc0cd8e9dfa3d2c41687e59e',1,'battle_ship::player']]]
];
