var searchData=
[
  ['width',['width',['../classbattle__ship_1_1vessel.html#ac69519345fd0c9a39b55a15516506461',1,'battle_ship::vessel']]]
];
