var searchData=
[
  ['hits',['hits',['../classbattle__ship_1_1vessel.html#a1a14cc37d607ba7f3b710b36a11ff2e0',1,'battle_ship::vessel']]]
];
