var searchData=
[
  ['username',['username',['../classbattle__ship_1_1player.html#aed786567891bcafecb8610e12fb5d413',1,'battle_ship::player']]]
];
