var searchData=
[
  ['x_5faxis',['x_axis',['../namespacebattle__ship.html#ab3bfa90e413692dac2d4463364f80561',1,'battle_ship']]],
  ['xy_5frepresentation_5fhorizontal',['xy_representation_horizontal',['../classbattle__ship_1_1vessel.html#a563ede7bcd45c64f897f727ce2ca50ff',1,'battle_ship::vessel']]],
  ['xy_5frepresentation_5fvertical',['xy_representation_vertical',['../classbattle__ship_1_1vessel.html#a7ab3092931ae7f230cb2cca77f2612c5',1,'battle_ship::vessel']]]
];
