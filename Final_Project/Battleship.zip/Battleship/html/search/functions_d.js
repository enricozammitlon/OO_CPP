var searchData=
[
  ['save_5ffleet',['save_fleet',['../classbattle__ship_1_1human.html#a3d14bca9009f7cfb8d4501d428524416',1,'battle_ship::human']]],
  ['save_5fhighscore',['save_highscore',['../classbattle__ship_1_1human.html#a5b7e6cad4d1f187907a205b767a2fd7d',1,'battle_ship::human::save_highscore()'],['../classbattle__ship_1_1npc.html#ab81843d30e5f8801a8fe479d44ead157',1,'battle_ship::npc::save_highscore()'],['../classbattle__ship_1_1player.html#a928538249678aea5402f8c673671e995',1,'battle_ship::player::save_highscore()']]],
  ['sell_5fpiece',['sell_piece',['../classbattle__ship_1_1market__manager.html#abfdff8ba2f4098656d9c53140c34876c',1,'battle_ship::market_manager']]],
  ['side_5fby_5fside',['side_by_side',['../classbattle__ship_1_1screen__manager.html#abb67a8f394b883d3f36136b40f35c3db',1,'battle_ship::screen_manager']]],
  ['signin',['signin',['../classbattle__ship_1_1authentication.html#a27046f1ace46e91bd6412ed35ddf0242',1,'battle_ship::authentication']]],
  ['signup',['signup',['../classbattle__ship_1_1authentication.html#aeb0c243e25547624235a562f657cfd63',1,'battle_ship::authentication']]],
  ['submarine',['submarine',['../classbattle__ship_1_1submarine.html#a52a8062290d2f36e162fc033a3917c5a',1,'battle_ship::submarine::submarine()=default'],['../classbattle__ship_1_1submarine.html#a229d0577e45bd964f4d32b50506c9504',1,'battle_ship::submarine::submarine(coordinates p, orientation o)']]]
];
