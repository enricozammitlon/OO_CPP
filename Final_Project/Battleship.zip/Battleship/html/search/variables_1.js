var searchData=
[
  ['budget',['budget',['../classbattle__ship_1_1player.html#a01f047aac5fcca92ff1e42d4d1e398c9',1,'battle_ship::player']]]
];
