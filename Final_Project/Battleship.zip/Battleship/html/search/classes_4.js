var searchData=
[
  ['game',['game',['../classbattle__ship_1_1game.html',1,'battle_ship']]],
  ['geometry',['geometry',['../classbattle__ship_1_1geometry.html',1,'battle_ship']]]
];
