var searchData=
[
  ['c',['C',['../namespacebattle__ship.html#ab3bfa90e413692dac2d4463364f80561a0d61f8370cad1d412f80b84d143e1257',1,'battle_ship']]],
  ['calculate_5fend',['calculate_end',['../classbattle__ship_1_1piece.html#a58092f7b1d663471204d7e51e68bbb2d',1,'battle_ship::piece::calculate_end()'],['../classbattle__ship_1_1vessel.html#a9b99c5ed2629203985b25338df585234',1,'battle_ship::vessel::calculate_end()']]],
  ['carrier',['carrier',['../classbattle__ship_1_1carrier.html',1,'battle_ship::carrier'],['../classbattle__ship_1_1carrier.html#a9eaaa54c8884c25a1f99c397df789ca0',1,'battle_ship::carrier::carrier()=default'],['../classbattle__ship_1_1carrier.html#a3bb443575cd2f35ab21981b984c0fa02',1,'battle_ship::carrier::carrier(coordinates p, orientation o)']]],
  ['carrier_2eh',['carrier.h',['../carrier_8h.html',1,'']]],
  ['col',['col',['../structbattle__ship_1_1coordinates.html#acda28ed24b163de319f6431762db3a72',1,'battle_ship::coordinates']]],
  ['coordinates',['coordinates',['../structbattle__ship_1_1coordinates.html',1,'battle_ship']]],
  ['coordinates_2ecpp',['coordinates.cpp',['../coordinates_8cpp.html',1,'']]],
  ['coordinates_2eh',['coordinates.h',['../coordinates_8h.html',1,'']]],
  ['cost',['cost',['../classbattle__ship_1_1vessel.html#aaf2677260fd0f0ce56678cd23b8a0591',1,'battle_ship::vessel']]],
  ['cruiser',['cruiser',['../classbattle__ship_1_1cruiser.html',1,'battle_ship::cruiser'],['../classbattle__ship_1_1cruiser.html#aa8fad74fb5caf3fd0cec5429b97fb46a',1,'battle_ship::cruiser::cruiser()=default'],['../classbattle__ship_1_1cruiser.html#a3460b4b49152a6653122e30224114115',1,'battle_ship::cruiser::cruiser(coordinates p, orientation o)']]],
  ['cruiser_2eh',['cruiser.h',['../cruiser_8h.html',1,'']]],
  ['current_5forientation',['current_orientation',['../classbattle__ship_1_1vessel.html#ae0e05c0f43e6fe6c01bf1534ebece971',1,'battle_ship::vessel']]],
  ['current_5fxy_5frepresentation',['current_xy_representation',['../classbattle__ship_1_1vessel.html#ac49c1b9fd8b63846dac12053cebb1d00',1,'battle_ship::vessel']]]
];
