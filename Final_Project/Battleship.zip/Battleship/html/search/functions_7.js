var searchData=
[
  ['index',['index',['../classbattle__ship_1_1board.html#a9518167fb31ba4fb53091cc9d86e7dba',1,'battle_ship::board']]],
  ['initialise_5fhighscores',['initialise_highscores',['../classbattle__ship_1_1highscore__manager.html#a404a994ea85111522a7a4f571bcbacdc',1,'battle_ship::highscore_manager']]],
  ['is_5fready_5fto_5fplay',['is_ready_to_play',['../classbattle__ship_1_1player.html#af5373e08a637e9c21b3751eb02e07540',1,'battle_ship::player']]]
];
