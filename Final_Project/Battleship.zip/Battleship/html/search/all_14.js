var searchData=
[
  ['width',['width',['../classbattle__ship_1_1vessel.html#ac69519345fd0c9a39b55a15516506461',1,'battle_ship::vessel']]],
  ['winning_5fline',['winning_line',['../classbattle__ship_1_1human.html#a583d0a9dd05c16f700d0d1825916faa3',1,'battle_ship::human::winning_line()'],['../classbattle__ship_1_1npc.html#a10c65edd38e75ac6be91ecd2dc9c9866',1,'battle_ship::npc::winning_line()'],['../classbattle__ship_1_1player.html#a3110ec708fd8fc7e02a6e88a63d57d2f',1,'battle_ship::player::winning_line()']]]
];
