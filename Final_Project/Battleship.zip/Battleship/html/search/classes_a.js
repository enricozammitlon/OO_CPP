var searchData=
[
  ['screen_5fmanager',['screen_manager',['../classbattle__ship_1_1screen__manager.html',1,'battle_ship']]],
  ['submarine',['submarine',['../classbattle__ship_1_1submarine.html',1,'battle_ship']]]
];
