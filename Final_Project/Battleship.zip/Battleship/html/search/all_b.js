var searchData=
[
  ['main',['main',['../battle_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'battle.cpp']]],
  ['market_5fmanager',['market_manager',['../classbattle__ship_1_1market__manager.html',1,'battle_ship']]],
  ['market_5fmanager_2ecpp',['market_manager.cpp',['../market__manager_8cpp.html',1,'']]],
  ['market_5fmanager_2eh',['market_manager.h',['../market__manager_8h.html',1,'']]],
  ['mask',['mask',['../classbattle__ship_1_1board.html#a0dd14fd999e0359ad0a3ecee47fe639d',1,'battle_ship::board']]],
  ['modify_5fbudget',['modify_budget',['../classbattle__ship_1_1player.html#ade02279db7265558659c40f16c482df7',1,'battle_ship::player']]],
  ['modify_5fcoordinate',['modify_coordinate',['../classbattle__ship_1_1board.html#a1c79f537306e8f2f84c8aa41a90430e6',1,'battle_ship::board']]],
  ['modify_5ffleet',['modify_fleet',['../classbattle__ship_1_1human.html#ab6e8f18828d7671bbc7645f38369d370',1,'battle_ship::human']]],
  ['modify_5fpose',['modify_pose',['../classbattle__ship_1_1piece.html#a052305c855625732d3e5ba96d0fca5f9',1,'battle_ship::piece::modify_pose()'],['../classbattle__ship_1_1vessel.html#ace0ec527147243b1fa6fa920d5a32a1f',1,'battle_ship::vessel::modify_pose()']]]
];
