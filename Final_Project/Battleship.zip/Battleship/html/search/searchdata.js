var indexSectionsWithContent =
{
  0: "abcdefghijlmnoprstuvwx~",
  1: "abcdghmnprsv",
  2: "b",
  3: "abcdghmnprsv",
  4: "abcdeghimnoprstvw~",
  5: "abcehlnprsuwx",
  6: "ox",
  7: "abcdefghijv",
  8: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "related"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerations",
  7: "Enumerator",
  8: "Friends"
};

