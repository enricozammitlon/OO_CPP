var searchData=
[
  ['start_5fcoordinates',['start_coordinates',['../classbattle__ship_1_1vessel.html#a32625627454fc279169a7d94ef460cd4',1,'battle_ship::vessel']]],
  ['subdir',['subdir',['../classbattle__ship_1_1player.html#a5cb155ee3d722244c44bf71e5e2440c4',1,'battle_ship::player']]]
];
