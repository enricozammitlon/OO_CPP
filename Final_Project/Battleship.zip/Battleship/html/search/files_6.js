var searchData=
[
  ['market_5fmanager_2ecpp',['market_manager.cpp',['../market__manager_8cpp.html',1,'']]],
  ['market_5fmanager_2eh',['market_manager.h',['../market__manager_8h.html',1,'']]]
];
