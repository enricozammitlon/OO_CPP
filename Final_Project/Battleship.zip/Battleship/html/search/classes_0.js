var searchData=
[
  ['authentication',['authentication',['../classbattle__ship_1_1authentication.html',1,'battle_ship']]]
];
