var searchData=
[
  ['piece',['piece',['../classbattle__ship_1_1piece.html',1,'battle_ship']]],
  ['player',['player',['../classbattle__ship_1_1player.html',1,'battle_ship']]]
];
