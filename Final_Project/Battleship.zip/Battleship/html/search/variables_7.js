var searchData=
[
  ['player_5fboard',['player_board',['../classbattle__ship_1_1player.html#a7a463dddbc0cd8e9dfa3d2c41687e59e',1,'battle_ship::player']]]
];
