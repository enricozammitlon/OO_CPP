var searchData=
[
  ['b',['B',['../namespacebattle__ship.html#ab3bfa90e413692dac2d4463364f80561a9d5ed678fe57bcca610140957afab571',1,'battle_ship']]]
];
