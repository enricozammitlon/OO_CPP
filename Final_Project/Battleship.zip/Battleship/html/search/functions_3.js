var searchData=
[
  ['destroyer',['destroyer',['../classbattle__ship_1_1destroyer.html#ae26647f7b12b2dc4cc1ef6951734a08b',1,'battle_ship::destroyer::destroyer()=default'],['../classbattle__ship_1_1destroyer.html#af0f630a4ecc4d6667b6adf021633da83',1,'battle_ship::destroyer::destroyer(coordinates p, orientation o)']]],
  ['display_5fxy',['display_xy',['../classbattle__ship_1_1piece.html#a0f900b13641277ae9e809e4baa5c8c10',1,'battle_ship::piece::display_xy()'],['../classbattle__ship_1_1vessel.html#a60924b058d686ebf545ae8f4d9f42d76',1,'battle_ship::vessel::display_xy()']]],
  ['do_5fintersect',['do_intersect',['../classbattle__ship_1_1geometry.html#a5415f69950638f0c84652b40d38e7ebd',1,'battle_ship::geometry']]]
];
