var searchData=
[
  ['carrier',['carrier',['../classbattle__ship_1_1carrier.html',1,'battle_ship']]],
  ['coordinates',['coordinates',['../structbattle__ship_1_1coordinates.html',1,'battle_ship']]],
  ['cruiser',['cruiser',['../classbattle__ship_1_1cruiser.html',1,'battle_ship']]]
];
