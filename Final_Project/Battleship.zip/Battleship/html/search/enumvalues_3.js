var searchData=
[
  ['d',['D',['../namespacebattle__ship.html#ab3bfa90e413692dac2d4463364f80561af623e75af30e62bbd73d6df5b50bb7b5',1,'battle_ship']]]
];
