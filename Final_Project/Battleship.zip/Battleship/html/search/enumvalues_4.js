var searchData=
[
  ['e',['E',['../namespacebattle__ship.html#ab3bfa90e413692dac2d4463364f80561a3a3ea00cfc35332cedf6e5e9a32e94da',1,'battle_ship']]]
];
