var searchData=
[
  ['on_5fsegment',['on_segment',['../classbattle__ship_1_1geometry.html#a69fccbb7267eb16930041fbdfeb1064a',1,'battle_ship::geometry']]],
  ['operator_28_29',['operator()',['../classbattle__ship_1_1board.html#a6977bbdbc6ed5855ea538dcec5a22699',1,'battle_ship::board']]],
  ['operator_3c_3c',['operator&lt;&lt;',['../classbattle__ship_1_1board.html#a9afa4baeef0df47e4a2efe05de9cb8eb',1,'battle_ship::board::operator&lt;&lt;()'],['../namespacebattle__ship.html#a8f319aebd93115655c5cfd648a988e01',1,'battle_ship::operator&lt;&lt;(std::ostream &amp;os, const board &amp;b)'],['../namespacebattle__ship.html#ac73c2d37116f5d6ed25e71eef5c37dc8',1,'battle_ship::operator&lt;&lt;(std::ostream &amp;os, const coordinates &amp;p)'],['../namespacebattle__ship.html#a1a93528abeff933fb4839aa528313c51',1,'battle_ship::operator&lt;&lt;(std::ostream &amp;os, const notification_manager &amp;n)']]],
  ['operator_3d',['operator=',['../classbattle__ship_1_1board.html#a4349c045147f686d09cdc47690f15e34',1,'battle_ship::board::operator=(const board &amp;b)'],['../classbattle__ship_1_1board.html#ae6dc011dea24157e59e2b3a6f34af586',1,'battle_ship::board::operator=(board &amp;&amp;b)']]],
  ['operator_3e_3e',['operator&gt;&gt;',['../namespacebattle__ship.html#ab0747cf7357f5f11e76979fdf9757861',1,'battle_ship']]],
  ['orientation',['orientation',['../classbattle__ship_1_1geometry.html#a319941076b65116cfb1ab1f636fb9b20',1,'battle_ship::geometry']]]
];
