var searchData=
[
  ['calculate_5fend',['calculate_end',['../classbattle__ship_1_1piece.html#a58092f7b1d663471204d7e51e68bbb2d',1,'battle_ship::piece::calculate_end()'],['../classbattle__ship_1_1vessel.html#a9b99c5ed2629203985b25338df585234',1,'battle_ship::vessel::calculate_end()']]],
  ['carrier',['carrier',['../classbattle__ship_1_1carrier.html#a9eaaa54c8884c25a1f99c397df789ca0',1,'battle_ship::carrier::carrier()=default'],['../classbattle__ship_1_1carrier.html#a3bb443575cd2f35ab21981b984c0fa02',1,'battle_ship::carrier::carrier(coordinates p, orientation o)']]],
  ['cruiser',['cruiser',['../classbattle__ship_1_1cruiser.html#aa8fad74fb5caf3fd0cec5429b97fb46a',1,'battle_ship::cruiser::cruiser()=default'],['../classbattle__ship_1_1cruiser.html#a3460b4b49152a6653122e30224114115',1,'battle_ship::cruiser::cruiser(coordinates p, orientation o)']]]
];
