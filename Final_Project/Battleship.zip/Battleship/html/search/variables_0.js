var searchData=
[
  ['action_5fpoints',['action_points',['../classbattle__ship_1_1vessel.html#a5d2b710e2b58847818ba8e22794a97a4',1,'battle_ship::vessel']]],
  ['all_5fhighscores',['all_highscores',['../classbattle__ship_1_1highscore__manager.html#a3a51d2dfb6210fea016ef59238d35861',1,'battle_ship::highscore_manager']]],
  ['all_5fpieces',['all_pieces',['../classbattle__ship_1_1market__manager.html#aa3d94799ba18b9a14edc9b2edc0ffd8d',1,'battle_ship::market_manager']]],
  ['already_5ftargeted',['already_targeted',['../classbattle__ship_1_1player.html#ac0905b76a660cd06e5fd45f4960d48f9',1,'battle_ship::player']]]
];
