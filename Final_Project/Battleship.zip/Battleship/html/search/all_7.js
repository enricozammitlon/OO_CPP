var searchData=
[
  ['h',['H',['../namespacebattle__ship.html#ab3bfa90e413692dac2d4463364f80561ac1d9f50f86825a1a2302ec2449c17196',1,'battle_ship']]],
  ['has_5fplayer_5flost',['has_player_lost',['../classbattle__ship_1_1game.html#a2f6eceb02db97507f52e08c1dafcf5e4',1,'battle_ship::game']]],
  ['has_5fsunk',['has_sunk',['../classbattle__ship_1_1piece.html#af22bd781f4206decd0beed89b014d1cc',1,'battle_ship::piece::has_sunk()'],['../classbattle__ship_1_1vessel.html#a5f36d687fbb87ced436d2d88847a1d5c',1,'battle_ship::vessel::has_sunk()']]],
  ['highscore_5fmanager',['highscore_manager',['../classbattle__ship_1_1highscore__manager.html',1,'battle_ship']]],
  ['highscore_5fmanager_2ecpp',['highscore_manager.cpp',['../highscore__manager_8cpp.html',1,'']]],
  ['highscore_5fmanager_2eh',['highscore_manager.h',['../highscore__manager_8h.html',1,'']]],
  ['hits',['hits',['../classbattle__ship_1_1vessel.html#a1a14cc37d607ba7f3b710b36a11ff2e0',1,'battle_ship::vessel']]],
  ['horizontal',['horizontal',['../namespacebattle__ship.html#aed87488f0a73f0d0679fe343fb61c784a4505cad087312551a6fbbe6ebe163e0f',1,'battle_ship']]],
  ['human',['human',['../classbattle__ship_1_1human.html',1,'battle_ship::human'],['../classbattle__ship_1_1human.html#abf9adbf70e2b5cec288c900f337f4c56',1,'battle_ship::human::human()=default'],['../classbattle__ship_1_1human.html#a9d8abd36c22aeddad8c57a5b1e74b4cd',1,'battle_ship::human::human(std::string uname, size_t high, size_t pass=0)']]],
  ['human_2ecpp',['human.cpp',['../human_8cpp.html',1,'']]],
  ['human_2eh',['human.h',['../human_8h.html',1,'']]]
];
