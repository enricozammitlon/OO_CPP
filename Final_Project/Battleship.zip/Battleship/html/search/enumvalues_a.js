var searchData=
[
  ['vertical',['vertical',['../namespacebattle__ship.html#aed87488f0a73f0d0679fe343fb61c784ae6dec152d6a941fccb0a5e8cc2579cc3',1,'battle_ship']]]
];
