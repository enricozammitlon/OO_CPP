var searchData=
[
  ['name',['name',['../classbattle__ship_1_1vessel.html#a7c7d199acda1b8914c1b014d7d2893b3',1,'battle_ship::vessel']]]
];
