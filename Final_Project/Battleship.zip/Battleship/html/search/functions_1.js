var searchData=
[
  ['board',['board',['../classbattle__ship_1_1board.html#a4d561505fe0c5d355e70bbd2bde1b00e',1,'battle_ship::board::board()'],['../classbattle__ship_1_1board.html#a72bdef4b84b4c2d8241b4307cae2cb9e',1,'battle_ship::board::board(const board &amp;b)'],['../classbattle__ship_1_1board.html#aae7ac9e7bbd44c1b2d7a745721936ee2',1,'battle_ship::board::board(board &amp;&amp;b)']]],
  ['boosted_5fx',['boosted_x',['../structbattle__ship_1_1coordinates.html#ab72dd07aa255aef070909f3070786680',1,'battle_ship::coordinates']]],
  ['boosted_5fy',['boosted_y',['../structbattle__ship_1_1coordinates.html#ae09ab4c8792c9f91159dcf11071d6717',1,'battle_ship::coordinates']]],
  ['buy_5fpiece',['buy_piece',['../classbattle__ship_1_1market__manager.html#afc7b9ed406cf2f728e658cec16232408',1,'battle_ship::market_manager']]]
];
