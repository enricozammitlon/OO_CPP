var searchData=
[
  ['h',['H',['../namespacebattle__ship.html#ab3bfa90e413692dac2d4463364f80561ac1d9f50f86825a1a2302ec2449c17196',1,'battle_ship']]],
  ['horizontal',['horizontal',['../namespacebattle__ship.html#aed87488f0a73f0d0679fe343fb61c784a4505cad087312551a6fbbe6ebe163e0f',1,'battle_ship']]]
];
