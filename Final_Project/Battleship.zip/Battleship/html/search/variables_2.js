var searchData=
[
  ['col',['col',['../structbattle__ship_1_1coordinates.html#acda28ed24b163de319f6431762db3a72',1,'battle_ship::coordinates']]],
  ['cost',['cost',['../classbattle__ship_1_1vessel.html#aaf2677260fd0f0ce56678cd23b8a0591',1,'battle_ship::vessel']]],
  ['current_5forientation',['current_orientation',['../classbattle__ship_1_1vessel.html#ae0e05c0f43e6fe6c01bf1534ebece971',1,'battle_ship::vessel']]],
  ['current_5fxy_5frepresentation',['current_xy_representation',['../classbattle__ship_1_1vessel.html#ac49c1b9fd8b63846dac12053cebb1d00',1,'battle_ship::vessel']]]
];
