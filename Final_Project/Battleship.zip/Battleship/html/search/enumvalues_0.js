var searchData=
[
  ['a',['A',['../namespacebattle__ship.html#ab3bfa90e413692dac2d4463364f80561a7fc56270e7a70fa81a5935b72eacbe29',1,'battle_ship']]]
];
