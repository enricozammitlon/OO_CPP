var searchData=
[
  ['g',['G',['../namespacebattle__ship.html#ab3bfa90e413692dac2d4463364f80561adfcf28d0734569a6a693bc8194de62bf',1,'battle_ship']]]
];
