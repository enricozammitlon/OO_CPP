var searchData=
[
  ['vertical',['vertical',['../namespacebattle__ship.html#aed87488f0a73f0d0679fe343fb61c784ae6dec152d6a941fccb0a5e8cc2579cc3',1,'battle_ship']]],
  ['vessel',['vessel',['../classbattle__ship_1_1vessel.html',1,'battle_ship::vessel'],['../classbattle__ship_1_1vessel.html#a6f3be9c2343940c262fb7add97402311',1,'battle_ship::vessel::vessel()=default'],['../classbattle__ship_1_1vessel.html#ade7f1d4ee4b458a715a0259e5211db20',1,'battle_ship::vessel::vessel(std::string n, coordinates p, size_t l, size_t w, std::string xy_rep_hor, std::string xy_rep_ver, orientation o, size_t ap)']]],
  ['vessel_2ecpp',['vessel.cpp',['../vessel_8cpp.html',1,'']]],
  ['vessel_2eh',['vessel.h',['../vessel_8h.html',1,'']]]
];
