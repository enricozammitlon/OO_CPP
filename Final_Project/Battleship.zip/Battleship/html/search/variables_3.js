var searchData=
[
  ['end_5fcoordinates',['end_coordinates',['../classbattle__ship_1_1vessel.html#a90baf292572ee968095c107ec656db32',1,'battle_ship::vessel']]],
  ['enemy',['enemy',['../classbattle__ship_1_1player.html#af01292346caaf209039b6490ae18d8aa',1,'battle_ship::player']]]
];
