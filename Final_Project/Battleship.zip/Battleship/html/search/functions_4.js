var searchData=
[
  ['edit_5fpiece',['edit_piece',['../classbattle__ship_1_1board.html#ab6dad94144c5142f3b956a78c6810a24',1,'battle_ship::board::edit_piece()'],['../classbattle__ship_1_1human.html#a8f0addc975b597a92d4c82849c2fff5d',1,'battle_ship::human::edit_piece()']]]
];
