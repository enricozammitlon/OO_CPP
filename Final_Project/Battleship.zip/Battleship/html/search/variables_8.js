var searchData=
[
  ['ready_5fto_5fplay',['ready_to_play',['../classbattle__ship_1_1player.html#a48a3f8c692c7ea1def384c39b9b65e85',1,'battle_ship::player']]],
  ['row',['row',['../structbattle__ship_1_1coordinates.html#a68c97ae4b9f30e2d5f20f3727546a29b',1,'battle_ship::coordinates']]]
];
